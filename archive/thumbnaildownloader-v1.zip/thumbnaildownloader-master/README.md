# Thumbnail Downloader
A tool that lets you simply download YouTube Thumbnails with only one click in the best quality available. Simple. Fast. Easy.

### Features

- picks the best available quality
- supports short links
- direct download from youtube

### Demo

Give it a try [here](https://kaibrune.github.io/thumbnaildownloader/).

### Missing a feature?

If you're missing a folder or option feel free to open a issue or fork my crappy code and try integrating it yourself! :)
